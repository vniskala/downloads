import sqlite3
import json

class Connection(object):

    def __init__(self):
        self._conn = None
    
    def __enter__(self):
        self._conn = sqlite3.connect("tasklist.db")
        return self._conn

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._conn.close()


class Database(object):

    def __init__(self):
        self._select_task_list_sql = 'SELECT owner, task_list_date FROM task_lists WHERE id = :task_list_id'
        self._insert_task_list_sql = 'INSERT INTO task_lists (owner, task_list_date) VALUES (?,?)'
        self._update_task_list_sql = 'UPDATE task_lists SET owner=:owner, task_list_date=:task_list_date WHERE id=:task_list_id'

        self._select_task_sql = 'SELECT id, order_number, content, done FROM tasks WHERE task_list_id = :task_list_id ORDER BY order_number'
        self._insert_task_sql = 'INSERT INTO tasks (task_list_id, order_number, content, done) VALUES (?,?,?,?)'
        self._delete_task_sql = 'DELETE FROM tasks WHERE task_list_id = :task_list_id'

    def get_task_list(self, task_list_id):
        return self._load_task_list(task_list_id)

    def update_task_list(self, task_list_id, task_list):
        self._update_task_list(task_list_id, task_list)
        return self._load_task_list(task_list_id)

    def store_task_list(self, task_list):
        task_list_id = self._insert_task_list(task_list)
        return self._load_task_list(task_list_id)

    def _insert_task_list(self, task_list):
        with Connection() as conn:
            cursor = conn.cursor()
            cursor.execute(self._insert_task_list_sql,
                           (task_list['owner'], task_list['task_list_date']))
            task_list_id = cursor.lastrowid
            conn.commit()
            self._insert_tasks(task_list_id, task_list['tasks'])
            return task_list_id

    def _update_task_list(self, task_list_id, task_list):
        with Connection() as conn:
            cursor = conn.cursor()
            cursor.execute(self._update_task_list_sql,
                           {'owner': task_list['owner'],
                            'task_list_date': task_list['task_list_date'],
                            'task_list_id': task_list_id})
            conn.commit()
            self._delete_tasks(task_list_id)
            self._insert_tasks(task_list_id, task_list['tasks'])
            return task_list_id
        
        
    def _insert_tasks(self, task_list_id, tasks):
        with Connection() as conn:
            cursor = conn.cursor()
            for task in tasks:
                cursor.execute(self._insert_task_sql,
                               (task_list_id, task['order_number'], task['content'], task['done']))
            conn.commit()
                
    def _delete_tasks(self, task_list_id):
        with Connection() as conn:
            cursor = conn.cursor()
            cursor.execute(self._delete_task_sql, {'task_list_id': task_list_id})
            conn.commit()
                
    def _load_task_list(self, task_list_id):
        print('task list id ' + str(task_list_id))
        with Connection() as conn:
            cursor = conn.cursor()
            cursor.execute(self._select_task_list_sql, {'task_list_id': task_list_id})
            result = cursor.fetchall()[0]
            task_list = {}
            task_list['id'] = task_list_id
            task_list['owner'] = result[0]
            task_list['task_list_date'] = result[1]
            cursor.close()
            task_list['tasks'] = self._load_tasks(task_list_id)
            print('Result: ' + str(task_list))
            return task_list

    def _load_tasks(self, task_list_id):
        with Connection() as conn:
            cursor = conn.cursor()
            cursor.execute(self._select_task_sql, {'task_list_id': task_list_id})
            result = cursor.fetchall()
            tasks = []
            for row in result:
                print('Row: ' + str(row))
                task = {}
                task['id'] = row[0]
                task['order_number'] = row[1]
                task['content'] = row[2]
                task['done'] = row[3]
                tasks.append(task)
            cursor.close()
            return tasks

        
    def insert_task(self, task):
        with Connection() as conn:
            cursor = conn.cursor()
            cursor.execute(insert_sql, task)
            conn.commit()

            
