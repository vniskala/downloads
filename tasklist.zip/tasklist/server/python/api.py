import bottle
import json
from mydb import Database

class API(object):

    def __init__(self):
        self._app = bottle.app()
        self._db = Database()

    def run(self):
        self.add_routes()
        bottle.run(host='127.0.0.1', port=8000, reloader=True, debug=True)

    def add_routes(self):
        self._app.route(path='/tasklists/<tasklist_id>', method='GET', callback=self.get_task_list)
        self._app.route(path='/tasklists/<tasklist_id>', method='PUT', callback=self.update_task_list)
        self._app.route(path='/tasklists', method='POST', callback=self.new_task_list)
        self._app.route(path='/tasklists', method='OPTIONS', callback=self.cors_response)
        self._app.route(path='/tasklists/<tasklist_id>', method='OPTIONS', callback=self.cors_response)

    def get_task_list(self, tasklist_id):
        bottle.response.add_header('Access-Control-Allow-Origin', '*')
        bottle.response.add_header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept')
        bottle.response.add_header('Access-Control-Allow-Methods', 'PUT, POST, GET, DELETE, OPTIONS')
        return self._db.get_task_list(tasklist_id)

    def update_task_list(self, tasklist_id):
        bottle.response.add_header('Access-Control-Allow-Origin', '*')
        bottle.response.add_header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept')
        bottle.response.add_header('Access-Control-Allow-Methods', 'PUT, POST, GET, DELETE, OPTIONS')
        task_list = bottle.request.json
        return self._db.update_task_list(tasklist_id, task_list)

    def cors_response(self, tasklist_id):
        bottle.response.add_header('Access-Control-Allow-Origin', '*')
        bottle.response.add_header('Access-Control-Allow-Headers', 'Origin, Content-Type, Accept, Access-Control-Allow-Origin, Access-Control-Allow-Methods')
        bottle.response.add_header('Access-Control-Allow-Methods', 'PUT, POST, GET, DELETE, OPTIONS')

    def new_task_list(self):
        task_list = bottle.request.json
        print('New task list ' + json.dumps(task_list))
        return self._db.store_task_list(task_list)
    
        
if __name__ == '__main__':
    api = API()
    api.run()
