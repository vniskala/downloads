CREATE TABLE task_lists (
   id INTEGER PRIMARY KEY,
   owner TEXT,
   task_list_date TEXT
   );

CREATE TABLE tasks (
   id INTEGER PRIMARY KEY,
   task_list_id INTEGER,
   order_number INTEGER,
   content TEXT NOT NULL,
   done INTEGER NOT NULL DEFAULT 0
   );
