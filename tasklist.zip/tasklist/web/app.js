var orderNumber = 0;

$.getJSON('http://127.0.0.1:8000/tasklists/1', function(data) {
    let text = `Task list of ${data.owner} for ${data.task_list_date}`
    document.getElementById("tasklistid").value = 1;
    document.getElementById("owner").value = data.owner;
    document.getElementById("tasklistdate").value = data.task_list_date;
    const headerPanel = document.getElementById("datapanel");
    headerPanel.innerHTML = text;
    let tasks = data.tasks;
    //var orderNumber = 0;
    const table = document.getElementById("tasklist");
    for (let task of tasks) {
	orderNumber++;
	let tr = table.insertRow();
	let contentCell = tr.insertCell();
	let contentInput = document.createElement("input");
	contentInput.setAttribute("type", "text");
	contentInput.setAttribute("name", "content_" + orderNumber);
	contentInput.setAttribute("value", task.content);
	contentCell.appendChild(contentInput);
	
	let idInput = document.createElement("input");
	idInput.setAttribute("type", "hidden");
	idInput.setAttribute("name", "taskid_" + orderNumber);
	idInput.setAttribute("value", task.id);
	contentCell.appendChild(idInput);
	
	let orderInput = document.createElement("input");
	orderInput.setAttribute("type", "hidden");
	orderInput.setAttribute("name", "ordernumber");
	orderInput.setAttribute("value", orderNumber);
	contentCell.appendChild(orderInput);
	
	let doneCell = tr.insertCell();
	let doneInput = document.createElement("input");
	doneInput.setAttribute("type", "checkbox");
	doneInput.setAttribute("name", "done_" + orderNumber);
	if (task.done == 1) {
	    doneInput.setAttribute("checked", "checked");
	}
	doneCell.appendChild(doneInput);
	
	let deleteCell = tr.insertCell();
	let deleteInput = document.createElement("input");
	deleteInput.setAttribute("type", "checkbox");
	deleteInput.setAttribute("name", "delete_" + orderNumber);
	deleteCell.appendChild(deleteInput);
    }
});

const addTask = document.getElementById("addTask");
addTask.addEventListener("click", function (event) {
    event.preventDefault();
    const table = document.getElementById("tasklist");
    orderNumber++;
    let tr = table.insertRow();
    let contentCell = tr.insertCell();
    let contentInput = document.createElement("input");
    contentInput.setAttribute("type", "text");
    contentInput.setAttribute("name", "content_" + orderNumber);
    contentCell.appendChild(contentInput);
    
    let idInput = document.createElement("input");
    idInput.setAttribute("type", "hidden");
    idInput.setAttribute("name", "taskid_" + orderNumber);
    idInput.setAttribute("value", 0);
    contentCell.appendChild(idInput);
    
    let orderInput = document.createElement("input");
    orderInput.setAttribute("type", "hidden");
    orderInput.setAttribute("name", "ordernumber");
    orderInput.setAttribute("value", orderNumber);
    contentCell.appendChild(orderInput);
    
    let doneCell = tr.insertCell();
    let doneInput = document.createElement("input");
    doneInput.setAttribute("type", "checkbox");
    doneInput.setAttribute("name", "done_" + orderNumber);
    doneCell.appendChild(doneInput);
    
    let deleteCell = tr.insertCell();
    let deleteInput = document.createElement("input");
    deleteInput.setAttribute("type", "checkbox");
    deleteInput.setAttribute("name", "delete_" + orderNumber);
    deleteCell.appendChild(deleteInput);
});

const form = document.getElementById("tasklistform");
form.addEventListener("submit", function (event) {
    event.preventDefault();
    let task_list = {};
    task_list.id = form.elements["tasklistid"].value;
    task_list.owner = form.elements["owner"].value;
    task_list.task_list_date = form.elements["tasklistdate"].value;
    let tasks = []
    let orderNumbers = form.elements["ordernumber"];
    if (orderNumbers.length == undefined) {
	let on = orderNumbers;
	orderNumbers = new Set();
	if (on != null) {
	    orderNumbers.add(on);
	}
    }
    for (let on of orderNumbers) {
	let task = {};
	task.order_number = on.value;
	task.id = form.elements["taskid_" + task.order_number].value;
	task.content = form.elements["content_" + task.order_number].value;
	task.done = form.elements["done_" + task.order_number].checked ? 1 : 0;
	if (!form.elements["delete_" + task.order_number].checked) {
	    tasks.push(task);
	}
    }
    task_list.tasks = tasks;
    
    let xhr = new XMLHttpRequest();
    let url = "http://localhost:8000/tasklists/" + task_list.id;
    xhr.open("PUT", url, false);
    xhr.setRequestHeader("Content-type", "application/json");
    xhr.setRequestHeader("Access-Control-Allow-Origin", "*");
    xhr.send(JSON.stringify(task_list));
    location.reload();
});
